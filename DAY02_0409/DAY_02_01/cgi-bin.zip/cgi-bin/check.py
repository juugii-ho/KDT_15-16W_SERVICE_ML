# HTML Header
print("Content-Type: text/html")
print()

# HTML Body
print('HELLO CGI!!!!!!!')
